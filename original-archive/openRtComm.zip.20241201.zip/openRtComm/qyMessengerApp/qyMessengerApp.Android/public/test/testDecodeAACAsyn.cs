
namespace qy.Droid
{

#if false
    public class DecodeAACAsyn : Thread
    {

        static string LOG_TAG = "";

        
        private Context context;
        
    private MediaFormat audioFormat;
        
    private File pcmFile;
        
    private static FileOutputStream fos = null;
        
    private static MediaCodec decodeCodec = null;



    private static LinkedBlockingQueue  mOutDataQueue = new Java.Util.Concurrent.LinkedBlockingQueue();
        //private Java.Util.IQueue<byte[]> mOutDataQueue = new LinkedBlockingQueue<>();

        private static LinkedBlockingQueue mInputDataQueue = new LinkedBlockingQueue();
    //private Queue<Integer> mInputDataQueue = new LinkedBlockingQueue<>();

    private static MediaExtractor audioExtractor = new MediaExtractor();

    private static Handler mHandler;



        public static Tmp_outRunnable outRunnable = new Tmp_outRunnable();

        public class Tmp_outRunnable : Java.Lang.Object, IRunnable
        {
            public void Run()
            {
                
            try
            {
                Log.Error(LOG_TAG, "outRunnable,��ǰ�̣߳� " + Thread.CurrentThread().Name);
                byte[] pcmData = (byte[])mOutDataQueue.Poll();
                if (pcmData == null)
                {
                    return;
                }
                Log.Error(LOG_TAG, "Handler�ص��յ�,��ǰ���ݴ�С��" + pcmData.Length);
                //װ��
                fos.Write(pcmData);//����д���ļ���
                fos.Flush();
            }
            catch (Exception e)
            {
                e.PrintStackTrace();
            }
                
            }
        };

        static Tmp_inputRunnable inputRunnable = new Tmp_inputRunnable();

        private class Tmp_inputRunnable : Java.Lang.Object, IRunnable
        {
            public void Run()
            {
                
                try
                {
                    Log.Error(LOG_TAG, "inputRunnable,��ǰ�̣߳� " + Thread.CurrentThread().Name);

                    int index = (int)mInputDataQueue.Poll();
                    if (index == null)
                    {
                        return;
                    }

                    ByteBuffer buffer;
                    if ((int)Build.VERSION.SdkInt >= 21)
                    {
                        buffer = decodeCodec.GetInputBuffer(index);
                    }
                    else
                    {
                        buffer = decodeCodec.GetInputBuffers()[index];
                    }
                    int sampleSize = audioExtractor.ReadSampleData(buffer, 0);
                    if (sampleSize < 0)
                    {
                        Log.Info(LOG_TAG, "��ǰ��Ƶ�Ѿ���ȡ����");
                        decodeCodec.QueueInputBuffer(index, 0, 0, 0, MediaCodecBufferFlags.EndOfStream);
                    }
                    else
                    {
                        Log.Info(LOG_TAG, "��ȡ������Ƶ���ݣ���ǰ��Ƶ���ݵ����ݳ���Ϊ��" + sampleSize);
                        long sampleTime = audioExtractor.SampleTime;
                        decodeCodec.QueueInputBuffer(index, 0, sampleSize, sampleTime, 0);
                        audioExtractor.Advance();
                    }
                }
                catch (Exception e)
                {
                    e.PrintStackTrace();
                }
                
            }
        };

        public DecodeAACAsyn(Activity demo5Activity)
        {
            context = demo5Activity;

            //
            Log.Error(LOG_TAG, "outRunnable,��ǰ�̣߳� " + Thread.CurrentThread().Name);

            //
            pcmFile = new File(context.GetExternalFilesDir(Environment.DirectoryMusic), "demo5a.pcm");
            try
            {
                pcmFile.CreateNewFile();
            }
            catch (IOException e)
            {
                e.PrintStackTrace();
            }
            

        }

        public class Tmp_Handler:Handler
        {
            DecodeAACAsyn m_mm;

            public Tmp_Handler(DecodeAACAsyn mm, Looper looper) : base(looper)
            {
                m_mm = mm;
            }

             
            public override void HandleMessage(Message msg)
            {
                base.HandleMessage(msg);
                if (msg.What == 0)
                {
                    m_mm.destory();
                }
            }

        }

    
        public class Tmp_MediaCodec_Callback:MediaCodec.Callback
            
        {
            
           
            public override void OnInputBufferAvailable( MediaCodec codec, int index)
            {
                Log.Error(LOG_TAG, "OnInputBufferAvailable,��ǰ�̣߳� " + Thread.CurrentThread().Name);

                //
                Log.Info(LOG_TAG, "�첽�ص���onInputBufferAvailable,��ǰindex:" + index);
                mInputDataQueue.Offer(index);
                mHandler.Post(inputRunnable);

            }

            public override void OnOutputBufferAvailable( MediaCodec codec, int index, MediaCodec.BufferInfo info)
            {
                Log.Error(LOG_TAG, "OnOutputBufferAvailable,��ǰ�̣߳� " + Thread.CurrentThread().Name);

                //
                Log.Info(LOG_TAG, "�첽�ص���onOutputBufferAvailable,��ǰindex:" + index);
                Log.Info(LOG_TAG, "��ȡ�������������ˣ���ǰ����������ݳ���Ϊ��" + info.Size);
                //�õ���ǰװ�����ȳ��Ŀ�
                ByteBuffer outputBuffer;
                if ((int)Build.VERSION.SdkInt >= 21)
                {
                    outputBuffer = codec.GetOutputBuffer(index);
                }
                else
                {
                    outputBuffer = codec.GetOutputBuffers()[index];
                }
                //�����ȳ��ŵ��µ���������ں���װ������
                byte[] pcmData = new byte[info.Size];
                outputBuffer.Get(pcmData);//д�뵽�ֽ�������
                outputBuffer.Clear();//��յ�ǰ��
                                     //��װ�������ݷŵ��������棬ͨ��handler������Ϣ�����߳�װ������
                mOutDataQueue.Offer(pcmData);
                mHandler.Post(outRunnable);
                //�ѿ�Żع�������
                codec.ReleaseOutputBuffer(index, false);

                if ((info.Flags & MediaCodecBufferFlags.EndOfStream) != 0)
                {
                    mHandler.SendEmptyMessage(0);
                }
            }


            public override void OnError( MediaCodec codec, MediaCodec.CodecException e)
            {
                Log.Info(LOG_TAG, "�첽�ص���onError" + e.ToString());
            }


            public override void OnOutputFormatChanged(MediaCodec codec, MediaFormat format)
            {
                Log.Info(LOG_TAG, "�첽�ص���onOutputFormatChanged" + format.ToString());

            }
        }


        public override void Run()
        {
            
        //base.Run();
        Looper.Prepare();
            mHandler = new Tmp_Handler(this,Looper.MyLooper());

    
    
    Log.Error(LOG_TAG, "Decode,��ǰ�̣߳� " + Thread.CurrentThread().Name);

    try
    {
        fos = new FileOutputStream(pcmFile.AbsoluteFile);
                //audioExtractor.SetDataSource(context.Resources.OpenRawResourceFd(Resource.Raw.dumppcm));
                AssetManager assets = context.Assets;
                audioExtractor.SetDataSource(assets.OpenFd("dumpPcm.mp3"));
                int count = audioExtractor.TrackCount;
        for (int i = 0; i < count; i++)
        {
            audioFormat = audioExtractor.GetTrackFormat(i);
            if (audioFormat.GetString(MediaFormat.KeyMime).StartsWith("audio/"))
            {
                audioExtractor.SelectTrack(i);
                Log.Info(LOG_TAG, "aac �ҵ���ͨ��" + i);
                break;
            }
        }

        //��ʼ��MiediaCodec
        decodeCodec = MediaCodec.CreateDecoderByType(audioFormat.GetString(MediaFormat.KeyMime));
        //
        // ͨ���ص���ʽ���������ݵı��룬�ȸղ��ֶ����÷�ʽ���������ص����������̣߳��ǵ��л��߳�
        //
        decodeCodec.SetCallback(new Tmp_MediaCodec_Callback());

    //������callBack��������config�����ݸ�ʽ��surface������Ⱦ��������������;�����õĶ��󣻱�־ encode ��1 decode��0
    decodeCodec.Configure(audioFormat, null, null, 0);

    //��������
    decodeCodec.Start();

            } catch (IOException e)
    {
        e.PrintStackTrace();
    }

    Looper.Loop();
            

        }

        public void destory()
        {

            Log.Info(LOG_TAG, "������Դ");
            if (audioExtractor != null)
            {
                audioExtractor.Release();
            }
            if (decodeCodec != null)
            {
                decodeCodec.Stop();
                decodeCodec.Release();
            }
            if (fos != null)
            {
                try
                {
                    fos.Close();
                }
                catch (IOException e)
                {
                    e.PrintStackTrace();
                }
            }
        }
        

    }
#endif

}
